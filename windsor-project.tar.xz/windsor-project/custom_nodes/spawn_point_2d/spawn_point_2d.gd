@icon("uid://uwrtqboyla0v")
extends Node2D
class_name WindsorSpawnPoint2D

@export var camera: PhantomCamera2D
var player: WindsorPlayer2D

var windsor_player: PackedScene = preload("res://custom_nodes/windsor_player_2d.scn")
var player_area: Area2D

func respawn() -> void:
	await get_tree().create_timer(0.1).timeout
	
	player.disconnect("dead", respawn)
	player.queue_free()
	player = windsor_player.instantiate()
	add_child(player)
	camera.follow_target = player
	player.spawn_position = global_position
	player.position = position
	player.connect("dead", respawn)

func _ready() -> void:
	player = windsor_player.instantiate()
	add_child(player)
	
	player.spawn_position = global_position
	player.global_position = global_position
	camera.follow_target = player

	player.connect("dead", respawn)
