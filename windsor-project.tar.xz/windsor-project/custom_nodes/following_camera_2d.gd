@tool

extends Camera2D
class_name FollowingCamera2D

@export var target: Node2D
@export var speed: float

# Called every frame. 'delta' is the elapsed time since the previous frame.
func _process(delta: float) -> void:
	var target_position = target.position
	position = position.move_toward(target_position, speed)
