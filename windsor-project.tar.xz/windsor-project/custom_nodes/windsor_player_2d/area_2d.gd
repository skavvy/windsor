extends Area2D

func send_signal(emit: String):
	if get_parent().has_signal(emit):
		get_parent().emit_signal(emit)
	else:
		push_error("Signal ", emit, " doesn't exist!")
