@tool
extends Polygon2D
class_name PolygonTerrain2D

var static_body: StaticBody2D
var collision_polygon: CollisionPolygon2D

func _init() -> void:
	static_body = StaticBody2D.new()
	collision_polygon = CollisionPolygon2D.new()
	
	static_body.collision_layer = 1
	
	static_body.add_child(collision_polygon)
	add_child(static_body)
	
	collision_polygon.polygon = polygon

func _process(delta: float) -> void:
	collision_polygon.polygon = polygon
